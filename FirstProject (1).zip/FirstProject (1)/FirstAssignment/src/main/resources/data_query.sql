INSERT INTO app.STUDENT(student_id,dob,name,yoa) values(1,'10/12/2000','sri','2012')
INSERT INTO app.STUDENT(student_id,dob,name,yoa) values(2,'10/12/2001','sneka','2012')
INSERT INTO app.STUDENT(student_id,dob,name,yoa) values(3,'10/05/2002','suba'	,'2012')

INSERT INTO app.STUDENT_MARKS(STUDENT_ID,MATHS,PHYSICS,CHEMISTRY) values(1,54,73,50)
INSERT INTO app.STUDENT_MARKS(STUDENT_ID,MATHS,PHYSICS,CHEMISTRY) values(2,58,40,75)
INSERT INTO app.STUDENT_MARKS(STUDENT_ID,MATHS,PHYSICS,CHEMISTRY) values(3,35,70,60)

INSERT INTO app.CONTACT (STUDENT_ID,MOBILE_NO,EMAIL,ADDRESS) values(1,'6677','srimail@email.com','bangalore')
INSERT INTO app.CONTACT (STUDENT_ID,MOBILE_NO,EMAIL,ADDRESS) values(2,'9595','snekamail@email.com','tamilnadu')
INSERT INTO app.CONTACT (STUDENT_ID,MOBILE_NO,EMAIL,ADDRESS) values(3,'9295','subamail@email.com','chennai')
package com.training.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.training.model.StudentMarksEntity;

import com.training.service.MarksService;

@RestController
public class MarksController {
	@Autowired
	MarksService markservice;

	@GetMapping("/studentmarks")
	public List<StudentMarksEntity> getmarks() {
		return markservice.getmarks();
	}
	@GetMapping("/studentmarksbyId/{id}")
	public Optional<StudentMarksEntity> getmarksbyId(@PathVariable Integer id) {
		return markservice.getmarksbyId(id);
	}

}


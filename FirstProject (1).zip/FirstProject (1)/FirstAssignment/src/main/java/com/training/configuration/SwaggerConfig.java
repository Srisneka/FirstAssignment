package com.training.configuration;

public class SwaggerConfig {

}

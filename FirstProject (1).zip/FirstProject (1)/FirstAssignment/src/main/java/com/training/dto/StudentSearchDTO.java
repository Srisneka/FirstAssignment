package com.training.dto;
/**
 * This is java document used for providing additional info
 */
public interface StudentSearchDTO {	
	public String getStudentId();	
	public String getName() ;
}
